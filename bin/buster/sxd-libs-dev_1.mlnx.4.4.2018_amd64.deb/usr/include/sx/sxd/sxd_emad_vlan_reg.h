/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_VLAN_REG_H__
#define __SXD_EMAD_VLAN_REG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_vlan_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_spvid_reg_t structure is used to store SPVID register
 * layout.
 */
typedef struct sxd_emad_spvid_reg {
    uint8_t tport;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved2;
    uint8_t egr_et_set;
    uint8_t et_vlan;
    net16_t pvid;
} PACK_SUFFIX sxd_emad_spvid_reg_t;

/**
 * sxd_emad_spvc_reg_t structure is used to store SPVC register
 * layout.
 */
typedef struct sxd_emad_spvc_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[7];
    uint8_t inner_et2_et2;
    uint8_t inner_et1_et1;
    uint8_t inner_et0_et0;
} PACK_SUFFIX sxd_emad_spvc_reg_t;

/**
 * sxd_emad_sver_reg_t structure is used to store SVER register
 * layout.
 */
typedef struct sxd_emad_sver_reg {
    uint8_t reserved1[4];
    net16_t ether_type0;
    uint8_t reserved2[2];
    net16_t ether_type1;
    uint8_t reserved3[2];
    net16_t ether_type2;
    uint8_t reserved4[2];
} PACK_SUFFIX sxd_emad_sver_reg_t;

/**
 * sxd_emad_spvm_vlan_record_t structure is used to store SPVM vlan
 * record layout.
 */
typedef struct sxd_emad_spvm_vlan_record {
    net16_t reserved1;
    net16_t ieu_vid;
} PACK_SUFFIX sxd_emad_spvm_vlan_record_t;

/**
 * sxd_emad_spvm_reg_t structure is used to store SPVM register
 * layout.
 */
typedef struct sxd_emad_spvm_reg {
    uint8_t                     prio_tagged;
    uint8_t                     local_port;
    uint8_t                     sub_port;
    uint8_t                     num_rec;
    sxd_emad_spvm_vlan_record_t records[0];
} PACK_SUFFIX sxd_emad_spvm_reg_t;

/**
 * sxd_emad_spvtr_reg_t structure is used to store SPVTR register
 * layout.
 */
typedef struct sxd_emad_spvtr_reg {
    uint8_t tport;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved2;
    uint8_t enable_bits;
    uint8_t ipvid_ipprio_mode;
    uint8_t reserved4;
    uint8_t epvid_mode;
} PACK_SUFFIX sxd_emad_spvtr_reg_t;

/**
 * sxd_emad_spaft_reg_t structure is used to store SPAFT register
 * layout.
 */
typedef struct sxd_emad_spaft_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved2;
    uint8_t aft;
    uint8_t reserved3[3];
} PACK_SUFFIX sxd_emad_spaft_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_VLAN_REG_H__ */
