/*
 * Copyright (C) Mellanox Technologies, Ltd. 2015-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SHSPM_H__
#define __SXD_EMAD_SHSPM_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_shspm_data.h>
#include <sx/sxd/sxd_emad_shspm_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_shspm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                   IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats RALTA register layout from RALTA register data.
 *
 * @param[in] ralta_data - RALTA register data.
 * @param[out] ralta_reg - RALTA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralta(sxd_emad_ralta_data_t *ralta_data,
                                  sxd_emad_ralta_reg_t  *ralta_reg);

/**
 *  This function formats RALTA register data from RALTA register layout.
 *
 * @param[out] ralta_data - RALTA register data.
 * @param[in] ralta_reg - RALTA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralta(sxd_emad_ralta_data_t *ralta_data,
                                    sxd_emad_ralta_reg_t  *ralta_reg);

/**
 *  This function formats RALST register layout from RALST register data.
 *
 * @param[in] ralst_data - RALST register data.
 * @param[out] ralst_reg - RALST register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralst(sxd_emad_ralst_data_t *ralst_data,
                                  sxd_emad_ralst_reg_t  *ralst_reg);

/**
 *  This function formats RALST register data from RALST register layout.
 *
 * @param[out] ralst_data - RALST register data.
 * @param[in] ralst_reg - RALST register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralst(sxd_emad_ralst_data_t *ralst_data,
                                    sxd_emad_ralst_reg_t  *ralst_reg);

/**
 *  This function formats RALTB register layout from RALTB register data.
 *
 * @param[in] raltb_data - RALTB register data.
 * @param[out] raltb_reg - RALTB register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_raltb(sxd_emad_raltb_data_t *raltb_data,
                                  sxd_emad_raltb_reg_t  *raltb_reg);

/**
 *  This function formats RALTB register data from RALTB register layout.
 *
 * @param[out] raltb_data - RALTB register data.
 * @param[in] raltb_reg - RALTB register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_raltb(sxd_emad_raltb_data_t *raltb_data,
                                    sxd_emad_raltb_reg_t  *raltb_reg);

/**
 *  This function formats RALUE register layout from RALUE register data.
 *
 * @param[in] ralue_data - RALUE register data.
 * @param[out] ralue_reg - RALUE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralue(sxd_emad_ralue_data_t *ralue_data,
                                  sxd_emad_ralue_reg_t  *ralue_reg);

/**
 *  This function formats RALUE register data from RALUE register layout.
 *
 * @param[out] ralue_data - RALUE register data.
 * @param[in] ralue_reg - RALUE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralue(sxd_emad_ralue_data_t *ralue_data,
                                    sxd_emad_ralue_reg_t  *ralue_reg);

/**
 *  This function formats RALEU register layout from RALEU register data.
 *
 * @param[in] raleu_data - RALEU register data.
 * @param[out] raleu_reg - RALEU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_raleu(sxd_emad_raleu_data_t *raleu_data,
                                  sxd_emad_raleu_reg_t  *raleu_reg);

/**
 *  This function formats RALEU register data from RALEU register layout.
 *
 * @param[out] raleu_data - RALEU register data.
 * @param[in] raleu_reg - RALEU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_raleu(sxd_emad_raleu_data_t *raleu_data,
                                    sxd_emad_raleu_reg_t  *raleu_reg);

/**
 *  This function formats RALBU register layout from RALBU register data.
 *
 * @param[in] ralbu_data - RALBU register data.
 * @param[out] ralbu_reg - RALBU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralbu(sxd_emad_ralbu_data_t *ralbu_data,
                                  sxd_emad_ralbu_reg_t  *ralbu_reg);

/**
 *  This function formats RALBU register data from RALBU register layout.
 *
 * @param[out] ralbu_data - RALBU register data.
 * @param[in] ralbu_reg - RALBU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralbu(sxd_emad_ralbu_data_t *ralbu_data,
                                    sxd_emad_ralbu_reg_t  *ralbu_reg);

#endif /* __SXD_EMAD_PARSER_SHSPM_H__ */
