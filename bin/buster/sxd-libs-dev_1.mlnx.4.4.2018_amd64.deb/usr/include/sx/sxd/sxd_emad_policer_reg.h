/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_POLICER_REG_H__
#define __SXD_EMAD_POLICER_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#include <complib/cl_packon.h>

/**
 * sxd_emad_qpcr_reg_t structure is used to store QPCR register
 * layout.
 */
typedef struct sxd_emad_qpcr_reg {
    uint8_t reserved1;
    uint8_t port;
    net16_t global_pid;
    uint8_t clear_add_counter;
    uint8_t reserved2;
    uint8_t color_aware_bytes_ir_units_type;
    uint8_t mode;
    uint8_t cbs;
    uint8_t ebs;
    uint8_t reserved3[2];
    net32_t cir;
    net32_t eir;
    uint8_t reserved5[3];
    uint8_t exceed_action;
    uint8_t reserved6[3];
    uint8_t violate_action;
    net32_t reserved7;
    net64_t violate_count;
} PACK_SUFFIX sxd_emad_qpcr_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_COS_REG_H__ */
