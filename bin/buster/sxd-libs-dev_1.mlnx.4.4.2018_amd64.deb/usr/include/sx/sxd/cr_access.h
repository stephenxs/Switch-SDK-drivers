/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2020 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef CR_ACCESS_H_
#define CR_ACCESS_H_

#include <sx/sxd/sxd_status.h>
/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * sx_cr_access_init
 *  This function initialize sx control register access handler.
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
int sx_cr_access_init(void);


/**
 * sx_cr_access_deinit
 *  This function deinitialize sx control register access handler.
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
int sx_cr_access_deinit(void);


/**
 * sx_cr_access_read
 *  This function read from dev_id at offset size of byte_len and put into returned data.
 *
 * @param[in] dev_id - Device ID to read from
 * @param[in] offset - Offset to begin read data from device ID
 * @param[out] data - Return read data from device ID
 * @param[in] byte_len - Number of bytes to read from device ID
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_access_read(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len);


/**
 * sx_cr_access_write
 *  This function writes the data into dev_id at offset size of byte_len.
 *
 * @param[in] dev_id - Device ID to write to
 * @param[in] offset - Offset to begin write data from device ID
 * @param[in] data - Data to write to device ID
 * @param[in] byte_len - Number of bytes to write into device ID (size of data)
 *
 * @return 0 if operation completes successfully.
 * @return -1 for failure
 */
sxd_status_t sx_cr_access_write(u_int8_t dev_id, unsigned int offset, u_int8_t *data, int byte_len);


#endif /* CR_ACCESS_H_ */
