/*
 *  Copyright (C) 2014-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_TUNNEL_H__
#define __SX_TUNNEL_H__

/************************************************
 *  Type definitions
 ***********************************************/

#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_cos.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_tunnel_id.h>

#include "sx/sdk/auto_headers/sx_tunnel_auto.h"

#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX)


#endif /* __SX_TUNNEL_H__ */
