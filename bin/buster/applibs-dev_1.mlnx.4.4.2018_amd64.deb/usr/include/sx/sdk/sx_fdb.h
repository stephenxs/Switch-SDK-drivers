/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_FDB_H__
#define __SX_FDB_H__


#include "sx/sdk/auto_headers/sx_fdb_auto.h"


/***********************************************
*  Types definition
***********************************************/

/**
 * Default FID.
 */
#define SX_FDB_DEFAULT_FID SXD_FDB_DEFAULT_FID

/**
 * Default FDB age time.
 */
#define SX_FDB_DEFAULT_AGE_TIME SXD_FDB_DEFAULT_AGE_TIME

/**
 * FDB maximum/minimum age time values.
 */
#define SX_FDB_AGE_TIME_MIN SXD_FDB_AGE_TIME_MIN
#define SX_FDB_AGE_TIME_MAX SXD_FDB_AGE_TIME_MAX

#define SX_FDB_IS_LIMIT_EXIST(val) SX_FDB_UC_NO_LIMIT != val

#define SX_FDB_UC_LIMIT_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_FDB_MAX_ENTRIES)

#define SX_FDB_IS_PORT_REDUNDANT(type, action) \
    (SX_FDB_UC_STATIC == type &&               \
     (SX_FDB_ACTION_TRAP == action || SX_FDB_ACTION_DISCARD == action || SX_FDB_ACTION_FORWARD_TO_ROUTER == action))

#define SX_FDB_IS_PORT_REDUNDANT_MASK(type, action) \
    ((0 != (type & SX_FDB_UC_TYPE_STATIC)) &&       \
     (SX_FDB_ACTION_TRAP == action || SX_FDB_ACTION_DISCARD == action || SX_FDB_ACTION_FORWARD_TO_ROUTER == action))


/**
 * Determine if the Ethernet address is multicast
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is the multicast address.
 */
static inline int is_multicast_ether_addr(const u_int8_t *addr)
{
    return (SX_FDB_GROUP_ADDRESS_MASK & addr[0]);
}

/**
 * Determine if the Ethernet address is broadcast
 * @addr: Pointer to a six-byte array containing the Ethernet address
 *
 * Return true if the address is the broadcast address.
 */
static inline int is_broadcast_ether_addr(const u_int8_t *addr)
{
    return (addr[0] & addr[1] & addr[2] & addr[3] & addr[4] & addr[5]) == 0xff;
}


#define SX_FDB_AGE_TIME_CHECK_RANGE(FDB_AGE_TIME) \
    SX_CHECK_RANGE(SX_FDB_AGE_TIME_MIN,           \
                   FDB_AGE_TIME,                  \
                   SX_FDB_AGE_TIME_MAX)

#define SX_FDB_POLL_INTERVAL_CHECK_RANGE(INTERVAL) \
    SX_CHECK_RANGE(SX_FDB_POLL_INTERVAL_DECISEC_MIN, INTERVAL, SX_FDB_POLL_INTERVAL_DECISEC_MAX)

#define SX_FDB_CHECK_GET_UC_RANGE(time) SX_CHECK_RANGE(1, time, SX_FDB_MAX_GET_ENTRIES)

#define SX_FDB_PGI_FLOOD_MIN_MAX (0), (SX_FDB_PGI_FLOOD_DEFAULT)
#define SX_FDB_PGI_CHECK_RANGE(pgi) SX_CHECK_MAX(pgi, SX_FDB_PGI_MAX)

#define SX_FDB_LEARN_MODE_CHECK_RANGE(mode) \
    SX_CHECK_MAX(mode, SX_FDB_LEARN_MODE_MAX)

#define SX_FDB_UC_MAC_ENTRY_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_FDB_UC_ENTRY_TYPE_MIN, (int)type, SX_FDB_UC_ENTRY_TYPE_MAX)

#define IS_MAC_ENTRY_DYNAMIC(type) \
    (type == SX_FDB_UC_REMOTE ||   \
     type == SX_FDB_UC_AGEABLE)

static __attribute__((__used__)) enum sfd_policy sfd_policy_arr[] = {
    SFD_POLICY_STATIC,
    SFD_POLICY_DYNAMIC_REMOTE, /* SFD_POLICY_DYNAMIC_LEARN */
    SFD_POLICY_INVALID,
    SFD_POLICY_DYNAMIC_AGEABLE
};

#define MAC_TYPE_TO_POLICY(mac_type) sfd_policy_arr[mac_type];

static __attribute__((__used__)) sx_fdb_uc_mac_entry_type_t mac_type_arr[] = {
    SX_FDB_UC_STATIC,
    SX_FDB_UC_REMOTE,
    SX_POLICY_INVALID,
    SX_FDB_UC_AGEABLE
};

#define POLICY_TO_MAC_TYPE(policy) mac_type_arr[policy];

#define SX_FDB_ACTION_CHECK_RANGE(type)           \
    ((type == SX_FDB_ACTION_FORWARD) ||           \
     (type == SX_FDB_ACTION_TRAP) ||              \
     (type == SX_FDB_ACTION_MIRROR_TO_CPU) ||     \
     (type == SX_FDB_ACTION_FORWARD_TO_ROUTER) || \
     (type == SX_FDB_ACTION_DISCARD) ||           \
     (type == SX_FDB_ACTION_INVALID))

static __attribute__((__used__)) enum sfd_action sfd_action_arr[] = {
    SFD_ACTION_FORWARD_ONLY,     /* 0 */
    SFD_ACTION_FORWARD_AND_TRAP,     /* 1 */
    SFD_ACTION_TRAP_ONLY,     /* 2 */
    SFD_ACTION_FORWARD_TO_IP_ROUTER,     /* 3 */
    SFD_ACTION_INVALID,     /* 4 */
    SFD_ACTION_INVALID,     /* 5 */
    SFD_ACTION_INVALID,     /* 6 */
    SFD_ACTION_INVALID,     /* 7 */
    SFD_ACTION_INVALID,     /* 8 */
    SFD_ACTION_INVALID,     /* 9 */
    SFD_ACTION_INVALID,     /* 10 */
    SFD_ACTION_INVALID,     /* 11 */
    SFD_ACTION_INVALID,     /* 12 */
    SFD_ACTION_INVALID,     /* 13 */
    SFD_ACTION_INVALID,     /* 14 */
    SFD_ACTION_DISCARD     /* 15 */
};

#define FDB_ACTION_TO_SFD_ACTION(action) sfd_action_arr[action];

/* Dynamic entries can only be configured with NOP(Forward) action. */
#define IS_FDB_ACTION_VALID_FOR_NVE(action_type, entry_type) \
    (((action_type == SX_FDB_ACTION_FORWARD) ||              \
      ((action_type == SX_FDB_ACTION_MIRROR_TO_CPU) &&       \
       (entry_type == SX_FDB_UC_STATIC))))

/* Maximum Unregister MC types with separate vector */
#define FLOOD_URMC_TYPES_MAX 2

#define CHECK_RANGE_FLOOD_TYPE(x) ((x) < FLOOD_TYPES_NUM_E)

#define SX_FLOOD_TABLES_EQUAL(t1, t2)    \
    ((t1)->table_id == (t2)->table_id && \
     (t1)->table_type == (t2)->table_type)

#define SX_FDB_NOTIFY_SIZE_THRESHOLD_CHECK_RANGE(SIZE) \
    SX_CHECK_RANGE(SX_FDB_NOTIFY_SIZE_MIN,             \
                   SIZE,                               \
                   SX_FDB_NOTIFY_SIZE_MAX)

#define SX_FDB_NOTIFY_TYPE_CHECK_RANGE(TYPE) SX_CHECK_RANGE(SX_FDB_NOTIFY_TYPE_MIN, (int)TYPE, SX_FDB_NOTIFY_TYPE_MAX)

#define SX_FDB_UNREG_FLOOD_MODE_CHECK_RANGE(val) \
    SX_CHECK_RANGE(SX_FDB_UNREG_FLOOD_MODE_MIN,  \
                   val,                          \
                   SX_FDB_UNREG_FLOOD_MODE_MAX)


#endif /* __SX_FDB_H__ */
