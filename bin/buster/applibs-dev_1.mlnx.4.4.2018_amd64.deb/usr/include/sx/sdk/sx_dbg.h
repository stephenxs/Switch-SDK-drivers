/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_DBG_H__
#define __SX_DBG_H__

#include <stdlib.h>
#include <stdint.h>

#include "sx/sdk/auto_headers/sx_dbg_auto.h"
#include "sx/sdk/auto_headers/sx_access_cmd_auto.h"


/************************************************
 *  Defines
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define SX_DBG_API_LOGGER_MODE_E_CHECK_RANGE(mode) \
    SX_CHECK_MAX((mode),                           \
                 SX_DBG_API_LOGGER_MODE_MAX)

#define SX_DBG_API_LOGGER_FILTER_MODE_E_CHECK_RANGE(mode) \
    SX_CHECK_MAX((mode),                                  \
                 SX_DBG_API_LOGGER_FILTER_MODE_MAX)


/************************************************
 *  Type definitions
 ***********************************************/

#endif /* __SX_DBG_H__ */
