/*
 *  Copyright (C) 2010-2020. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_PORT_ID_H__
#define __SX_PORT_ID_H__


#include "sx/sdk/auto_headers/sx_port_id_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_PORT_DEV_ID_CHECK_RANGE(id) SX_CHECK_RANGE(SX_PORT_DEV_ID_MIN, id, SX_PORT_DEV_ID_MAX)
#define SX_PORT_LCL_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_LCL_ID_MAX)
#define SX_PORT_PHY_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_PHY_ID_MAX)
#define SX_PORT_SUB_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_SUB_ID_MAX)
#define SX_PORT_LOG_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_LOG_ID_MAX)
#define SX_PORT_UCR_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_UCR_ID_MAX)

#define SX_PORT_PHY_ID_MIN_MAX SX_PORT_PHY_ID_MIN, SX_PORT_PHY_ID_MAX
#define SX_PORT_SUB_ID_MIN_MAX SX_PORT_SUB_ID_MIN, SX_PORT_PHY_ID_MAX

#define SX_PORT_TYPE_ID_ISO(id) ((id) & (SX_PORT_TYPE_ID_MASK))
#define SX_PORT_DEV_ID_ISO(id)  ((id) & (SX_PORT_DEV_ID_MASK))
#define SX_PORT_LCL_ID_ISO(id)  ((id) & (SX_PORT_PHY_ID_MASK))
#define SX_PORT_PHY_ID_ISO(id)  ((id) & (SX_PORT_PHY_ID_MASK))
#define SX_PORT_SUB_ID_ISO(id)  ((id) & (SX_PORT_SUB_ID_MASK))
#define SX_PORT_LAG_ID_ISO(id)  ((id) & (SX_PORT_LAG_ID_MASK))
#define SX_PORT_VLAN_ID_ISO(id) ((id) & (SX_PORT_VLAN_ID_MASK))

#define SX_PORT_TYPE_ID_GET(id) (SX_PORT_TYPE_ID_ISO(id) >> SX_PORT_TYPE_ID_OFFS)
#define SX_PORT_DEV_ID_GET(id)  (SX_PORT_DEV_ID_ISO(id) >> SX_PORT_DEV_ID_OFFS)
#define SX_PORT_LCL_ID_GET(id)  (SX_PORT_LCL_ID_ISO(id) >> SX_PORT_LCL_ID_OFFS)
#define SX_PORT_PHY_ID_GET(id)  (SX_PORT_PHY_ID_ISO(id) >> SX_PORT_PHY_ID_OFFS)
#define SX_PORT_SUB_ID_GET(id)  (SX_PORT_SUB_ID_ISO(id) >> SX_PORT_SUB_ID_OFFS)
#define SX_PORT_LAG_ID_GET(id)  (SX_PORT_LAG_ID_ISO(id) >> SX_PORT_LAG_ID_OFFS)
#define SX_PORT_VLAN_ID_GET(id) (SX_PORT_VLAN_ID_ISO(id) >> SX_PORT_VLAN_ID_OFFS)

#define SX_PORT_TYPE_ID_CLR(id) ((id) &= ~(SX_PORT_TYPE_ID_MASK))
#define SX_PORT_DEV_ID_CLR(id)  ((id) &= ~(SX_PORT_DEV_ID_MASK))
#define SX_PORT_LCL_ID_CLR(id)  ((id) &= ~(SX_PORT_LCL_ID_MASK))
#define SX_PORT_PHY_ID_CLR(id)  ((id) &= ~(SX_PORT_PHY_ID_MASK))
#define SX_PORT_SUB_ID_CLR(id)  ((id) &= ~(SX_PORT_SUB_ID_MASK))
#define SX_PORT_LAG_ID_CLR(id)  ((id) &= ~(SX_PORT_LAG_ID_MASK))
#define SX_PORT_VLAN_ID_CLR(id) ((id) &= ~(SX_PORT_VLAN_ID_MASK))

#define SX_PORT_TYPE_ID_SET(id, TYPE_ID) ((id) |= SX_PORT_TYPE_ID_ISO((TYPE_ID) << (SX_PORT_TYPE_ID_OFFS)))
#define SX_PORT_DEV_ID_SET(id, DEV_ID)   ((id) |= SX_PORT_DEV_ID_ISO((DEV_ID) << (SX_PORT_DEV_ID_OFFS)))
#define SX_PORT_LCL_ID_SET(id, LCL_ID)   ((id) |= SX_PORT_LCL_ID_ISO((LCL_ID) << (SX_PORT_LCL_ID_OFFS)))
#define SX_PORT_PHY_ID_SET(id, PHY_ID)   ((id) |= SX_PORT_PHY_ID_ISO((PHY_ID) << (SX_PORT_PHY_ID_OFFS)))
#define SX_PORT_SUB_ID_SET(id, SUB_ID)   ((id) |= SX_PORT_SUB_ID_ISO((SUB_ID) << (SX_PORT_SUB_ID_OFFS)))
#define SX_PORT_LAG_ID_SET(id, LAG_ID)   ((id) |= SX_PORT_LAG_ID_ISO((LAG_ID) << (SX_PORT_LAG_ID_OFFS)))
#define SX_PORT_VLAN_ID_SET(id, VLAN_ID) ((id) |= SX_PORT_VLAN_ID_ISO((VLAN_ID) << (SX_PORT_VLAN_ID_OFFS)))

#define M_PRINT_PORT_LOG_ID_MEMBERS(log_port_id)                                                          \
    {                                                                                                     \
        SX_LOG_DBG("Logical port: 0x%08X, Type: 0x%01X, Device: 0x%03X, Phy id: 0x%02X,Sub id: 0x%02X\n", \
                   log_port_id,                                                                           \
                   SX_PORT_TYPE_ID_GET(log_port_id),                                                      \
                   SX_PORT_DEV_ID_GET(log_port_id),                                                       \
                   SX_PORT_PHY_ID_GET(log_port_id),                                                       \
                   SX_PORT_SUB_ID_GET(log_port_id));                                                      \
    }

#define M_PRINT_LCL_PORT_ID_MEMBERS(lcl_port_id)                \
    {                                                           \
        SX_LOG_DBG("Logical port: %u, Phy id: %d,Sub id: %d\n", \
                   lcl_port_id,                                 \
                   SX_PORT_PHY_ID_GET(lcl_port_id),             \
                   SX_PORT_SUB_ID_GET(lcl_port_id));            \
    }

#define SX_PORT_VPORT_BUILD(vport, vlan, phy_port)  \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_VPORT); \
    SX_PORT_VLAN_ID_SET(vport, vlan);               \
    SX_PORT_PHY_ID_SET(vport, phy_port)

#define SX_PORT_VPORT_LAG_BUILD(vport, vlan, lag_id) \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_VPORT);  \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_LAG);    \
    SX_PORT_VLAN_ID_SET(vport, vlan);                \
    SX_PORT_PHY_ID_SET(vport, lag_id)


typedef struct sx_port_vrt_id_bits {
    uint32_t phy_id : SX_PORT_PHY_ID_NUM_OF_BITS; /* Physical Port ID   */
    uint32_t sub_id : SX_PORT_SUB_ID_NUM_OF_BITS; /* Sub Port ID        */
} sx_port_vrt_id_bits_t;

typedef union sx_port_vrt_id_pkt {
    uint32_t              value;
    sx_port_vrt_id_bits_t bits;
} sx_port_vrt_id_pkt_t;

typedef sx_port_vrt_id_bits_t sx_port_lcl_id_bits_t;
typedef sx_port_vrt_id_pkt_t sx_port_lcl_id_pkt_t;

#endif /* __SX_PORT_ID_H__ */
