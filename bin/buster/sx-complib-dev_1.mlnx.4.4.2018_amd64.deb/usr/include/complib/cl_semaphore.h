/*
 * Copyright (c) 2004, 2005 Voltaire, Inc. All rights reserved.
 * Copyright (c) 2002-2005 Mellanox Technologies LTD. All rights reserved.
 * Copyright (c) 1996-2003 Intel Corporation. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

/*
 * Abstract:
 *	Declaration of semaphore abstraction.
 */

#ifndef _CL_SEMAPHORE_H_
#define _CL_SEMAPHORE_H_

/* Indicates that waiting on an semaphore should never timeout */
#define SEMAPHORE_NO_TIMEOUT 0xFFFFFFFF

#include <complib/cl_semaphore_osd.h>

#ifdef __cplusplus
#  define BEGIN_C_DECLS extern "C" {
#  define END_C_DECLS   }
#else               /* !__cplusplus */
#  define BEGIN_C_DECLS
#  define END_C_DECLS
#endif              /* __cplusplus */

BEGIN_C_DECLS

/****f* Component Library: Semaphore/cl_semaphore_init
 * NAME
 *	cl_semaphore_init
 *
 * DESCRIPTION
 *	The cl_semaphore_init function initializes a semaphore for use.
 *
 * SYNOPSIS
 */
cl_status_t cl_semaphore_init(IN cl_semaphore_t * const p_sem, IN const uint32_t value);
/*
 * PARAMETERS
 *	p_sem
 *		[in] Pointer to a cl_semaphore_t structure to initialize.
 *
 *	value
 *		[in] Initial value of the semaphore.
 *
 * RETURN VALUES
 *	CL_SUCCESS if semaphore initialization succeeded.
 *
 *	CL_ERROR otherwise.
 *
 * NOTES
 *	Allows calling semaphore manipulation functions, such as cl_semaphore_destroy,
 *	cl_semaphore_wait, cl_semaphore_release.
 *
 * SEE ALSO
 *	Semaphore, cl_semaphore_destroy, cl_semaphore_wait, cl_semaphore_release
 *********/

/****f* Component Library: Semaphore/cl_semaphore_destroy
 * NAME
 *	cl_semaphore_destroy
 *
 * DESCRIPTION
 *	The cl_semaphore_destroy function performs any necessary cleanup of an semaphore.
 *
 * SYNOPSIS
 */
cl_status_t cl_semaphore_destroy(IN cl_semaphore_t * const p_sem);

/*
 * PARAMETERS
 *	p_sem
 *		[in] Pointer to an cl_semaphore_t structure to destroy.
 *
 * RETURN VALUE
 *	CL_SUCCESS if semaphore initialization succeeded.
 *
 *	CL_ERROR otherwise.
 *
 * NOTES
 *	This function should only be called after a call to cl_semaphore_init.
 *
 * SEE ALSO
 *	Semaphore, cl_semaphore_init
 *********/

/****f* Component Library: Semaphore/cl_semaphore_release
 * NAME
 *	cl_semaphore_release
 *
 * DESCRIPTION
 *	The cl_semaphore_release function increments the value of a semaphore.
 *
 * SYNOPSIS
 */
cl_status_t cl_semaphore_release(IN cl_semaphore_t * const p_sem);
/*
 * PARAMETERS
 *	p_sem
 *		[in] Pointer to an cl_semaphore_t structure to set.
 *
 * RETURN VALUES
 *	CL_SUCCESS if the semaphore was successfully incremented.
 *
 *	CL_ERROR otherwise.
 *
 * NOTES
 *	This function wakes up another thread that blocks on the semaphore if the previous value was 0.
 *
 * SEE ALSO
 *	Semaphore, cl_semaphore_wait_on
 *********/

/****f* Component Library: Semaphore/cl_semaphore_wait_on
 * NAME
 *	cl_semaphore_wait_on
 *
 * DESCRIPTION
 *	The cl_semaphore_wait_on function decrements the value of a semaphore.
 *
 * SYNOPSIS
 */
cl_status_t cl_semaphore_wait_on(IN cl_semaphore_t * const p_sem, IN const uint32_t wait_us);
/*
 * PARAMETERS
 *	p_sem
 *		[in] Pointer to an cl_semaphore_t structure on which to wait.
 *
 *	wait_us
 *		[in] Number of microseconds to wait.
 *
 * RETURN VALUES
 *	CL_SUCCESS if the wait operation succeeded.
 *
 *	CL_TIMEOUT if the specified time period elapses.
 *
 *	CL_ERROR if the wait operation failed.
 *
 * NOTES
 *	If the value of the semaphore is greater than zero, the operation succeeds immediately.
 *	Otherwise, the function blocks and waits for some other thread to release (increment the value) of the semaphore
 *	before current thread acquires it and decrement it back.
 *	If wait_us is set to SEMAPHORE_NO_TIMEOUT, the function will wait until the semaphore is released and never timeout.
 *	If wait_us is is zero, this function simply tests the state of the semaphore.
 *
 * SEE ALSO
 *	Semaphore, cl_semaphore_signal
 *********/

/***** Component Library: Semaphore/cl_semaphore_wait_on_seconds
 * NAME
 *             cl_semaphore_wait_on_seconds
 *
 * DESCRIPTION
 *             Same functionality as cl_semaphore_wait_on.
 *             The cl_semaphore_wait_on_seconds function gets wait time in seconds.
 *             For additional information, please see cl_semaphore_wait_on synopsis.
 *
 * SYNOPSIS
 */
cl_status_t cl_semaphore_wait_on_seconds(IN cl_semaphore_t * const p_sem,
                                         IN const uint32_t         wait_second);

END_C_DECLS
#endif              /* _CL_SEMAPHORE_H_ */
