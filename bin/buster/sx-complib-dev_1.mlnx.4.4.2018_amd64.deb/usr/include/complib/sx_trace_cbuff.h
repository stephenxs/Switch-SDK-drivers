/*
 * Copyright (c) 2004-2006 Voltaire, Inc. All rights reserved.
 * Copyright (c) 2002-2005 Mellanox Technologies LTD. All rights reserved.
 * Copyright (c) 1996-2003 Intel Corporation. All rights reserved.
 *
 * This software is available to you under a choice of one of two
 * licenses.  You may choose to be licensed under the terms of the GNU
 * General Public License (GPL) Version 2, available from the file
 * COPYING in the main directory of this source tree, or the
 * OpenIB.org BSD license below:
 *
 *     Redistribution and use in source and binary forms, with or
 *     without modification, are permitted provided that the following
 *     conditions are met:
 *
 *      - Redistributions of source code must retain the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer.
 *
 *      - Redistributions in binary form must reproduce the above
 *        copyright notice, this list of conditions and the following
 *        disclaimer in the documentation and/or other materials
 *        provided with the distribution.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */

#ifndef __SX_TRACE_CBUFF_H__
#define __SX_TRACE_CBUFF_H__

#include <syslog.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <complib/cl_types.h>
#include <complib/sx_log.h>

#ifndef __MODULE__
#define __MODULE__ TRACE_CBUFF
#endif

#define TRACE_CBUFF_DEFAULT_DUMP_PATH "/tmp/sx_trace_cbuff_dump.txt"
#define TRACE_CBUFF_LINE_SIZE_MAX     1024
#define TRACE_CBUFF_LOG_SIZE_MAX      10000


/***** APIs *****/

int sx_trace_cbuff_init(uint32_t log_lines_max);

void sx_trace_cbuff_deinit(void);

void sx_trace_cbuff_dump(const char *path_to_dump);

void sx_trace_cbuff_log(char const *p_str, ...);

#define SX_TRACE_CBUFF(fmt, arg ...)                        \
    do {                                                    \
        sx_trace_cbuff_log("%s[%d]: " fmt,                  \
                           __FUNCTION__, __LINE__, ## arg); \
    } while (0)

#endif /* __SX_TRACE_CBUFF_H__ */
